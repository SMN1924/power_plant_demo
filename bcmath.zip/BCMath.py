import numpy as np
from typing import Any, List
import json
from ekuiper import Function, Context

class BCStdFunc(Function):

    def __init__(self):
        pass

    def validate(self, args: List[Any]):
        if len(args) != 1:
            return "expect only one parameters"
        return ""

    def exec(self, args: List[Any], ctx: Context):
        open_vol = []
        work_vol = []
        b_vol = []

        #for i in args[0]:
        jsonObj = args[0]
        for j in range(1, 7, 1):
            dessKey = "dess1"
            bmKey = "bm1"
            jKey = "j" + str(j)
            open_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("elec").get("open_vol"))
            work_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("elec").get("work_vol"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol01"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol02"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol03"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol04"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol05"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol06"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol07"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol08"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol09"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol10"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol11"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol12"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol13"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol14"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol15"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol16"))

        open_vol_std  = np.std(np.array(open_vol))
        work_vol_std = np.std(np.array(work_vol))
        b_vol_std = np.std(np.array(b_vol))
        result = {
            "open_vol_std":open_vol_std,
            "work_vol_std":work_vol_std,
            "b_vol_std":b_vol_std,
            "open_vol_arr":open_vol,
            "work_vol_arr":work_vol,
            "battery_vol_arr":b_vol
        }
        return result

    def is_aggregate(self):
        return False
