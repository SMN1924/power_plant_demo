# This is a sample Python script.

from ekuiper import plugin, PluginConfig
from BCMath import BCStdFunc

if __name__ == '__main__':
    c = PluginConfig("bcmath", {}, {},
                     {"bcstd": lambda: BCStdFunc()})
    plugin.start(c)

