import numpy as np
from typing import Any, List
import json
from ekuiper import Function, Context

class CellcalcFunc(Function):

    def __init__(self):
        pass

    def validate(self, args: List[Any]):
        if len(args) != 1:
            return "expect only one parameters"
        return ""

    def exec(self, args: List[Any], ctx: Context):
        b_vol = []

        #for i in args[0]:
        jsonObj = args[0]
        for j in range(1, 7, 1):
            dessKey = "dess1"
            bmKey = "bm1"
            jKey = "j" + str(j)
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol01"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol02"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol03"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol04"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol05"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol06"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol07"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol08"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol09"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol10"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol11"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol12"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol13"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol14"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol15"))
            b_vol.append(jsonObj.get(dessKey).get(bmKey).get(jKey).get("ebtu").get("vol16"))

        b_vol_array = np.array(b_vol)
        b_vol_diff = b_vol_array.ptp()   #电压极差
        b_vol_std = np.std(b_vol_array)   #电压标准差
        b_vol_mean = np.mean(b_vol_array)   #电压平均值
        b_vol_variation = b_vol_std / b_vol_mean   #电压变异系数
        result = {
            "b_vol_diff":b_vol_diff,
            "b_vol_std":b_vol_std,
            "b_vol_mean":b_vol_mean,
            "b_vol_variation":b_vol_variation
        }
        return result

    def is_aggregate(self):
        return False
