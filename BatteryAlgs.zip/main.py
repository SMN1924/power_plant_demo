# This is a sample Python script.

from ekuiper import plugin, PluginConfig
from BatteryAlgs import CellcalcFunc

if __name__ == '__main__':
    c = PluginConfig("BatteryAlgs", {}, {},
                     {"cellcalc": lambda: CellcalcFunc()})
    plugin.start(c)

